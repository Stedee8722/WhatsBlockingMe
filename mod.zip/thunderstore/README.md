# What's Blocking Me?

A debug mod to print info to the loading screen and add an option to bypass it

## Install

Either install automatically through Thunderstore or download the zip file and do it manually.
Just place the folder extracted from the zip into your mod folder

## Dependencies

[GDWeave](https://thunderstore.io/c/webfishing/p/NotNet/GDWeave/)
